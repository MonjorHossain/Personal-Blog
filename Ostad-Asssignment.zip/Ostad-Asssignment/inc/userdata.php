
<?php


    $connection = mysqli_connect('localhost:3306','monjorho_monjor','Rida2023#','monjorho_perblog'); 
if (!$connection){
    echo "There are some problem while connecting the database !";
}
else{
    echo "MESSAGE IS SENT SUCCESSFULLY";
}



// =================================================================
// This is for Localhost Server :

//     $connection = mysqli_connect('localhost','root','','perblog'); 
// if (!$connection){
//     echo "There are some problem while connecting the database !";
// }
// else{
//     echo "MESSAGE IS SENT SUCCESSFULLY";
// }


    ?>


                    