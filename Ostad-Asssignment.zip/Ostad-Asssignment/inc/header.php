<header id="logo_menu">
        <div class="container">
            <div class="row">
                <div class="col-md-4 logo_img">
                    <div class="logo_area">
                        <a href="index.php"><img src="img/mylogo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="menu_area">
                        <ul>
                            <li><a href="index.php" class="active">Home</a></li>
                            <li><a href="blog.php">Blog</a></li>
                            <li><a href="contact.php">Contact</a></li>
                            <li><a href="about.php">About Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <a href="post.php?id=<?=$post['id']?>" style="text-decoration:none;color:black">