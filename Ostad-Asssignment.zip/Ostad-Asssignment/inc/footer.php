    <footer id="footer_area">
        <div id="copyright_area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p><a href="#">&copy; Copyright 2023 | Monjor Hossain</a></p>
                     </div>
                 </div>
            </div>
        </div>
	</footer>