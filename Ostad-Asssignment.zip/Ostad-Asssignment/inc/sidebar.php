                    <div class="col-md-3">
                        <section class="sidebar">
                            <div id="search_area">
                                <h2>Search Here</h2>
                                <form action="#" method="get">
                                    <input type="text" name="search" placeholder="Search...">
                                    <button type="submit" class="sidebar_btn">Go</button>
                                </form>
                            </div>
                            <div id="category">
                                <h2>List of Category</h2>
                                <ul>
                                    <li><a href="#">Category 1</a></li>
                                    <li><a href="#">Category 2</a></li>
                                    <li><a href="#">Category 3</a></li>
                                    <li><a href="#">Category 4</a></li>
                                    <li><a href="#">Category 5</a></li>
                                    <li><a href="#">Category 6</a></li>
                                    <li><a href="#">Category 7</a></li>
                                    <li><a href="#">Category 8</a></li>
                                </ul>
                            </div>
                        </section>
                    </div>
