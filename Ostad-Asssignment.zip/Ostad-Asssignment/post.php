
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monjor Personal Blog</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bxslider.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="database">
    <?php
    include('inc/userdata.php');

    ?>
</div>
    <?php include_once('inc/header.php') ?>

    <section id="contact_form">
        <div class="container m-auto mt-3">
            <div class="row">
                <div class="col-md-9">

                    <?php

                        $post_id=$_GET['id'];
                        $postQuery="SELECT * FROM posts WHERE id=$post_id";
                        $runPQ=mysqli_query($connection,$postQuery);
                        $post=mysqli_fetch_assoc($runPQ);
        
                    ?>


                    <div class="card mb-3">
                        
                        <div class="card-body">
                        <h5 class="card-title"><?=$post['title']?></h5>
                        <span class="badge bg-primary ">Posted on <?=date('F jS, Y',strtotime($post['created_at']))?></span>
                        <span class="badge bg-danger">Web Development</span>
                        <div class="border-bottom mt-3"></div>
                        <img src="img/slider_02.jpg" class="img-fluid mb-2 mt-2" alt="Responsive image">
                        <p class="card-text mb-3"><?php echo $post['content'] ?></p>
                        <a href="#" class="btn btn-primary">Share this post</a>
                        <a href="#" class="btn btn-primary">Comment on this</a>

                        </div>
                    </div>
                </div>

                    <?php include_once('inc/sidebar.php') ?>
            </div>
        </div>
    </section>

    <?php include_once('inc/footer.php') ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/bxslider.min.js"></script> 
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>

