
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monjor Personal Blog</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bxslider.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="database">
    <?php
    include('inc/userdata.php');

    ?>
</div>
    <?php include_once('inc/header.php') ?>

    <section id="slider_area">
        <div class="inner_slider container">
            <div class="slider_area">
                <div class="item">
                    <div class="slider_caption">
                        <h1>Welcome</h1>
                    </div>
                    <img src="img/slider_01.jpg" alt="">
                </div>
                <div class="item">
                    <div class="slider_caption">
                        <h1 id="Rida">Rida Hossain</h1>
                    </div>
                    <img src="img/slider_02.jpg" alt="">
                </div>
                <div class="item">
                    <div class="slider_caption">
                        <h1>Fatiha</h1>
                    </div>
                    <img src="img/3.jpg" alt="">
                </div>
                <div class="item">
                    <img src="img/slider_04.jpg" alt="">
                </div>
                <div class="item">
                    <img src="img/slider_05.jpg" alt="">
                </div>
                <div class="item">
                    <img src="img/slider_6.jpg" alt="">
                </div>
            </div>

        </div>
    </section>

    <section id="main_body">
        <div class="container m-auto mt-3 row">
            <div class="col-md-8">


            <div class="card mb-3">
                
                <div class="card-body">
                  <h5 class="card-title">Featured Post</h5>
                  <span class="badge bg-primary ">Posted on 13 Feb, 2021</span>
                  <span class="badge bg-danger">Web Development</span>
                  <div class="border-bottom mt-3"></div>
                  <img src="img/slider_03.jpg" class="img-fluid mb-2 mt-2" alt="Responsive image">
                  <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                  </p>

                  <a href="featured_post.php" class="btn btn-danger mt-3 ms-2">Read More</a>


                </div>
            </div>            


            <!-- ================================= -->

            <?php
            
            $postQuery="SELECT * FROM posts";
            $runPQ=mysqli_query($connection,$postQuery);
            while($post=mysqli_fetch_assoc($runPQ)){
                ?>
                <div class="card mb-3" style="max-width: 800px;">
                    <a href="post.php?id=<?=$post['id']?>" style="text-decoration:none;color:black">         
                    <div class="row g-0">
                        <div class="col-md-5" style="background-image:url('img/slider_02.jpg');background-size:  cover">

                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $post['title'] ?></h5>
                                <p class="card-text text-truncate"><?php echo $post['content'] ?></p>
                                <p class="card-text"><small class="text-muted">Posted on <?=date('F jS, Y',strtotime($post['created_at']))?></small></p>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
                <?php

            }
            ?>

        

            </div>
 
                <?php include_once('inc/sidebar.php') ?>
           
        </div>
    </section>

    <?php include_once('inc/footer.php') ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/bxslider.min.js"></script> 
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>