
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monjor Personal Blog</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bxslider.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
<div id="database">
    <?php
    include('inc/userdata.php');

    ?>
</div>
    <?php include_once('inc/header.php') ?>


    <section id="main_body">
        <div class="container m-auto mt-3 row">
            <div class="col-md-8">
                       
            <?php
            
            $postQuery="SELECT * FROM posts";
            $runPQ=mysqli_query($connection,$postQuery);
            while($post=mysqli_fetch_assoc($runPQ)){
                ?>
                <div class="card mb-3" style="max-width: 800px;">
    <a href="post.php" style="text-decoration:none;color:black">         
                    <div class="row g-0">
                        <div class="col-md-5" style="background-image:url('img/slider_02.jpg');background-size:  cover">

                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $post['title'] ?></h5>
                                <p class="card-text text-truncate"><?php echo $post['content'] ?></p>
                                <p class="card-text"><small class="text-muted">Posted on <?=date('F jS, Y',strtotime($post['created_at']))?></small></p>
                            </div>
                        </div>
                    </div>
        </a>
                </div>
                <?php

            }
            ?>

        

            </div>
 

                <?php include_once('inc/sidebar.php') ?>

           
        </div>
    </section>

    <?php include_once('inc/footer.php') ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/bxslider.min.js"></script> 
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>