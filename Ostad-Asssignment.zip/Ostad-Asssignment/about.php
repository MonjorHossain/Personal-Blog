
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monjor Personal Blog</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bxslider.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php include_once('inc/header.php') ?>


    <section id="main_body">
        <div class="container m-auto mt-3 row">
            <div class="col-md-8">


                <div class="card mb-3">
                
                    <div class="card-body">
                        <h5 class="card-title">About Us</h5>
                        <span class="badge bg-primary ">Posted on 13 Feb, 2021</span>
                        <span class="badge bg-danger">Web Development</span>
                        <div class="border-bottom mt-3"></div>
                        <img src="img/Monjor Hossain (6).png" class="img-fluid mb-2 mt-2" alt="Responsive image">
                        <p class="card-text mb-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                        </p>
                        <a href="#" class="btn btn-primary mb-3">Share this post</a>
                        <a href="#" class="btn btn-primary mb-3">Comment on this</a>
                    </div>
                </div>            
            </div>
 
                <?php include_once('inc/sidebar.php') ?>          
        </div>
    </section>

    <?php include_once('inc/footer.php') ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/bxslider.min.js"></script> 
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>