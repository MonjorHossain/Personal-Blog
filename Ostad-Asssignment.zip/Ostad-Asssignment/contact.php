
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monjor Personal Blog</title>
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bxslider.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <?php include_once('inc/header.php') ?>

        <div class="container">
            <div class="row m-auto mt-3">
                <div class="col-md-12 mb-4">
                    <h1>Contact Us</h1>
                    <form method="post" action="inc/userdata.php">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" placeholder="Write Your Name" required>

                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Write Your Email" required>

                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" placeholder="Write Your Subject" required>

                        <label for="message">Message</label>
                        <textarea id="message" name="message" placeholder="Write Your Message" required></textarea>

                        <button type="submit">Submit</button>
                    </form>

                </div>

            </div>
        </div>


    <?php include_once('inc/footer.php') ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/bxslider.min.js"></script> 
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>