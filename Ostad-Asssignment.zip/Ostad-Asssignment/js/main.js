// Bx Slider
$(document).ready(function(){
    $('.slider_area').bxSlider({
      mode:'fade',
      speed: 1700,
      pause: 2000,
      auto: true,
      pager: true,
      controls: true,
      touchEnabled: true,
    });
  });